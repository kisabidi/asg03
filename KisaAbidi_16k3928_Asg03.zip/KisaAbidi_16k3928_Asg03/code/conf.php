
<?php       
   $con = null;
    error_reporting(E_ERROR | E_PARSE);
    if(isset($_POST['MasPasswordSubmit'])){
        $pass = $_POST['MasPassword'];
        $con  = mysqli_connect("localhost","id15366521_k173604",$pass,"id15366521_wpasg3_k173604");
         
        if(!$con) {
            session_start();
            $_SESSION["Login"] = "NO";
            echo "<h2>You are NOT logged in correctly<br>Redirecting to Previous Page! </h2>";
            header("Refresh:1; url=index.php");

        }
        else{
            session_start();
            $_SESSION["Login"] = "YES";
            echo "<h1>You are now logged in correctly</h1>";  
            header("Refresh:1; url=data.php");
             
        }
    }
?>