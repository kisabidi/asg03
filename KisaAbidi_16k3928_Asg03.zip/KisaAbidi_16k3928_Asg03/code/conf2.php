<?php
$con  = mysqli_connect("localhost","id15366521_k173604","2R1YFgaOX>2Bb<88","id15366521_wpasg3_k173604"); 
?>         