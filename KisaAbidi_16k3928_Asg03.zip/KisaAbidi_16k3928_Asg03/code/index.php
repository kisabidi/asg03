<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assigment3</title>
</head>

<body>
    <form action="conf.php" method="POST">
        <h3>Master Password:</h3>
        <div>
            <input type="password" name="MasPassword" id="MasPassword">
            <input type="SUBMIT" name="MasPasswordSubmit" value="..." id="MasPasswordSubmit">
        </div>
    </form>


</body>

</html>